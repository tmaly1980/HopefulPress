require 'test_helper'

class SessionsControllerTest < ActionController::TestCase
  test 'should create a user session' do
    assert false, 'Write this test'
  end
  
  test 'should redirect to home page' do
    assert false, 'Write this test'
  end
  
end
