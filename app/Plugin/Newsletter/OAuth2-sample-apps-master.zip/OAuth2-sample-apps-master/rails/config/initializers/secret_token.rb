# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MailchimpOauth::Application.config.secret_token = '8957f8d9379361ba923336944186866bc9457d40e7ef39ae261eed35d386a41606998b534bc6aafb09db7f2aaa62ce1f7d87015f22ef88c315bcf024eb15ff2b'
