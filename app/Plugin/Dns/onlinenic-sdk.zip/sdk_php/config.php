<?php
/**
 * 
 * Api Demo Configure
 * @author CHENWP
 * 
 */
return array(
	'server' => '218.5.81.149',
	'port' => '30009',
	'user' => '135610',
	'pass' => '654123',
	'timeout' => 30, //The connection timeout, in seconds.
	'log_record' => false, //Record the log file
	'log_path' => '/tmp/domainlog/',//linux:Directories have write permissions. windows��'log_path' => 'C:\\www\\apilog\\'
);
